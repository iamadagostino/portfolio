import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  // If language is not supported, redirect to root and let it auto-detect
  if (!language) {
    throw redirect('/');
  }

  // Language is supported, continue with normal rendering
  return { lang: language };
};

// Re-export everything from contact
export { Contact as default, meta, action, handle } from './contact/contact';
