export { Slice as default, meta } from './slice';
