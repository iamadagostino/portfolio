import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // Redirect to posts index
  throw redirect(`/${language}/admin/posts`);
};
