import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // Only allow Italian language for "progetti" route
  if (language !== 'it') {
    throw redirect(`/${language}/projects/volkihar-knight`);
  }

  return { lang: language };
};

// Re-export everything from the volkihar-knight project
export {
  VolkiharKnight as default,
  meta,
} from '~/routes/projects.volkihar-knight/volkihar-knight';

export const handle = {
  i18n: ['common', 'projects'],
};
