import { useParams } from '@remix-run/react';

export default function Contact() {
  const { lang } = useParams();

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">
        {lang === 'it' ? 'Contattami' : 'Contact Me'}
      </h1>
      <p className="text-lg mb-4">
        {lang === 'it' ? 'Questa è la pagina dei contatti.' : 'This is the contact page.'}
      </p>
      <p className="text-sm text-gray-600">Current language: {lang}</p>
    </div>
  );
}
