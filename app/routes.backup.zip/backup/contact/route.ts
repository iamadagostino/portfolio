export { Contact as default, meta, action } from './contact';
