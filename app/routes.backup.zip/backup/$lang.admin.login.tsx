import type { LoaderFunctionArgs, ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { Form, useActionData, useNavigation } from '@remix-run/react';
import {
  adminLogin,
  createAdminSession,
  getAdminUser,
} from '~/services/admin-auth.server';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // If already logged in as admin, redirect to dashboard
  const adminUser = await getAdminUser(request);
  if (adminUser) {
    throw redirect(`/${language}/admin/dashboard`);
  }

  return { language };
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  const formData = await request.formData();
  const email = formData.get('email') as string;
  const password = formData.get('password') as string;

  if (!email) {
    return { error: 'Email is required' };
  }

  try {
    const user = await adminLogin(email, password);

    if (!user) {
      return { error: 'Invalid credentials or insufficient permissions' };
    }

    // Get redirect URL from search params
    const url = new URL(request.url);
    const redirectTo =
      url.searchParams.get('redirectTo') || `/${language}/admin/dashboard`;

    return createAdminSession(user.id, redirectTo);
  } catch {
    return { error: 'Login failed. Please try again.' };
  }
};

export default function AdminLogin() {
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();
  const isSubmitting = navigation.state === 'submitting';

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      }}
    >
      <div
        style={{
          background: 'white',
          padding: '2rem',
          borderRadius: '12px',
          boxShadow: '0 20px 40px rgba(0, 0, 0, 0.1)',
          width: '100%',
          maxWidth: '400px',
          margin: '1rem',
        }}
      >
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <h1
            style={{
              fontSize: '1.75rem',
              fontWeight: 'bold',
              margin: '0 0 0.5rem 0',
              color: '#2c3e50',
            }}
          >
            Admin Login
          </h1>
          <p style={{ color: '#6c757d', margin: 0 }}>Sign in to access the admin panel</p>
        </div>

        <Form
          method="post"
          style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}
        >
          <div>
            <label
              htmlFor="email"
              style={{
                display: 'block',
                marginBottom: '0.5rem',
                fontWeight: '500',
                color: '#374151',
              }}
            >
              Email Address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              required
              autoComplete="email"
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #d1d5db',
                borderRadius: '8px',
                fontSize: '1rem',
                transition:
                  'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out',
                boxSizing: 'border-box',
              }}
              onFocus={e => {
                e.target.style.borderColor = '#667eea';
                e.target.style.boxShadow = '0 0 0 3px rgba(102, 126, 234, 0.1)';
              }}
              onBlur={e => {
                e.target.style.borderColor = '#d1d5db';
                e.target.style.boxShadow = 'none';
              }}
              placeholder="admin@angelo-dagostino.com"
            />
          </div>

          <div>
            <label
              htmlFor="password"
              style={{
                display: 'block',
                marginBottom: '0.5rem',
                fontWeight: '500',
                color: '#374151',
              }}
            >
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              autoComplete="current-password"
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #d1d5db',
                borderRadius: '8px',
                fontSize: '1rem',
                transition:
                  'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out',
                boxSizing: 'border-box',
              }}
              onFocus={e => {
                e.target.style.borderColor = '#667eea';
                e.target.style.boxShadow = '0 0 0 3px rgba(102, 126, 234, 0.1)';
              }}
              onBlur={e => {
                e.target.style.borderColor = '#d1d5db';
                e.target.style.boxShadow = 'none';
              }}
              placeholder="Enter your password"
            />
          </div>

          {actionData?.error && (
            <div
              style={{
                padding: '0.75rem',
                background: '#fef2f2',
                border: '1px solid #fecaca',
                borderRadius: '8px',
                color: '#dc2626',
                fontSize: '0.875rem',
              }}
            >
              {actionData.error}
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            style={{
              width: '100%',
              padding: '0.75rem',
              fontSize: '1rem',
              fontWeight: '600',
              marginTop: '0.5rem',
              backgroundColor: isSubmitting ? '#6c757d' : '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: isSubmitting ? 'not-allowed' : 'pointer',
              transition: 'background-color 0.15s ease-in-out',
            }}
            onMouseEnter={e => {
              if (!isSubmitting) {
                (e.target as HTMLButtonElement).style.backgroundColor = '#5a6fd8';
              }
            }}
            onMouseLeave={e => {
              if (!isSubmitting) {
                (e.target as HTMLButtonElement).style.backgroundColor = '#667eea';
              }
            }}
          >
            {isSubmitting ? 'Signing in...' : 'Sign In'}
          </button>
        </Form>

        <div
          style={{
            marginTop: '2rem',
            padding: '1rem',
            background: '#f8f9fa',
            borderRadius: '8px',
            fontSize: '0.875rem',
            color: '#6c757d',
          }}
        >
          <strong>Development Note:</strong> For development, use the admin email from
          your database. Password validation is currently disabled in development mode.
        </div>
      </div>
    </div>
  );
}
