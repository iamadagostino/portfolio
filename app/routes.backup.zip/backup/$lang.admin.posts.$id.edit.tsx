import type { LoaderFunctionArgs, ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { Form, useActionData, useNavigation, useLoaderData } from '@remix-run/react';
import { useState, useEffect } from 'react';
import { prisma } from '~/.server/db';
import { getGalleryImages } from '~/services/upload.server';
import { ImageGallery, type ImageData } from '~/components/image-gallery';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { requireAdminUser } from '~/services/admin-auth.server';
import { AdminLayout } from '~/layouts/admin';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);
  const postId = params.id;

  if (!language || !postId) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  try {
    // Get the post with translations
    const post = await prisma.post.findUnique({
      where: { id: parseInt(postId) },
      include: {
        author: {
          select: { username: true, firstName: true, lastName: true },
        },
        translations: true,
      },
    });

    if (!post) {
      throw new Response('Post not found', { status: 404 });
    }

    // Get gallery images for banner selection
    const galleryImages = await getGalleryImages();
    const images: ImageData[] = galleryImages.map(img => ({
      ...img,
      createdAt: img.createdAt.toISOString(),
    }));

    return { post, images, language };
  } catch (error) {
    console.error('Edit post loader error:', error);
    throw new Response('Failed to load post', { status: 500 });
  }
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);
  const postId = params.id;

  if (!language || !postId) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  const formData = await request.formData();
  const intent = formData.get('intent');

  if (intent === 'delete') {
    try {
      await prisma.post.delete({
        where: { id: parseInt(postId) },
      });
      return redirect(`/${language}/admin/posts`);
    } catch {
      return {
        error: 'Failed to delete post',
        post: null,
      };
    }
  }

  const slug = (formData.get('slug') as string) || '';
  const slugEn = (formData.get('slugEn') as string) || '';
  const slugIt = (formData.get('slugIt') as string) || '';
  const titleEn = (formData.get('titleEn') as string) || '';
  const titleIt = (formData.get('titleIt') as string) || '';
  const abstractEn = (formData.get('abstractEn') as string) || '';
  const abstractIt = (formData.get('abstractIt') as string) || '';
  const contentEn = (formData.get('contentEn') as string) || '';
  const contentIt = (formData.get('contentIt') as string) || '';
  const featured = formData.get('featured') === 'on';
  const banner = (formData.get('banner') as string) || '';
  const status = (formData.get('status') as string) || 'DRAFT';

  // Validate required fields
  if (!slug || !titleEn || !abstractEn || !contentEn) {
    return {
      error: 'Missing required fields: slug, titleEn, abstractEn, contentEn',
      post: null,
    };
  }

  try {
    // Check if slug already exists (excluding current post)
    const existingPost = await prisma.post.findFirst({
      where: {
        slug,
        NOT: { id: parseInt(postId) },
      },
    });

    if (existingPost) {
      return {
        error: 'A post with this slug already exists. Please use a different slug.',
        post: null,
      };
    }

    // Update post basic info
    await prisma.post.update({
      where: { id: parseInt(postId) },
      data: {
        slug,
        status: status as 'DRAFT' | 'PUBLISHED' | 'ARCHIVED',
        featured,
        banner: banner || null,
        readTime: Math.ceil(contentEn.split(' ').length / 200),
        publishedAt: status === 'PUBLISHED' ? new Date() : null,
      },
    });

    // Update or create English translation
    await prisma.postTranslation.upsert({
      where: {
        postId_language: { postId: parseInt(postId), language: 'EN' },
      },
      update: {
        title: titleEn,
        abstract: abstractEn,
        content: contentEn,
        slug: slugEn && slugEn !== slug ? slugEn : null,
        metaTitle: `${titleEn} - Angelo D'Agostino`,
        metaDescription: abstractEn,
      },
      create: {
        postId: parseInt(postId),
        language: 'EN',
        title: titleEn,
        abstract: abstractEn,
        content: contentEn,
        slug: slugEn && slugEn !== slug ? slugEn : null,
        metaTitle: `${titleEn} - Angelo D'Agostino`,
        metaDescription: abstractEn,
      },
    });

    // Handle Italian translation
    if (titleIt && contentIt) {
      await prisma.postTranslation.upsert({
        where: {
          postId_language: { postId: parseInt(postId), language: 'IT' },
        },
        update: {
          title: titleIt,
          abstract: abstractIt || abstractEn,
          content: contentIt,
          slug: slugIt && slugIt !== slug ? slugIt : null,
          metaTitle: `${titleIt} - Angelo D'Agostino`,
          metaDescription: abstractIt || abstractEn,
        },
        create: {
          postId: parseInt(postId),
          language: 'IT',
          title: titleIt,
          abstract: abstractIt || abstractEn,
          content: contentIt,
          slug: slugIt && slugIt !== slug ? slugIt : null,
          metaTitle: `${titleIt} - Angelo D'Agostino`,
          metaDescription: abstractIt || abstractEn,
        },
      });
    } else {
      // Delete Italian translation if not provided
      await prisma.postTranslation.deleteMany({
        where: { postId: parseInt(postId), language: 'IT' },
      });
    }

    return redirect(`/${language}/admin/posts`);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      error: `Failed to update post: ${message}`,
      post: null,
    };
  }
};

export default function EditPost() {
  const { post, images } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();
  const isSubmitting = navigation.state === 'submitting';

  // Form state
  const [selectedBanner, setSelectedBanner] = useState<string>(post.banner || '');
  const [galleryImages, setGalleryImages] = useState<ImageData[]>(images);
  const [showGallery, setShowGallery] = useState(false);
  const [activeTab, setActiveTab] = useState<'main' | 'en' | 'it'>('main');

  // Update selected banner when post changes
  useEffect(() => {
    setSelectedBanner(post.banner || '');
  }, [post.banner]);

  const englishTranslation = post.translations.find(t => t.language === 'EN');
  const italianTranslation = post.translations.find(t => t.language === 'IT');

  return (
    <AdminLayout
      title={`Edit: ${englishTranslation?.title || post.slug}`}
      subtitle="Update post content and settings"
    >
      {actionData?.error && (
        <div
          style={{
            padding: '1rem',
            backgroundColor: '#f8d7da',
            color: '#721c24',
            borderRadius: '6px',
            marginBottom: '2rem',
            border: '1px solid #f5c6cb',
          }}
        >
          <strong>Error:</strong> {actionData.error}
        </div>
      )}

      <div
        style={{
          background: 'white',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        }}
      >
        <div
          style={{
            padding: '1.5rem',
            borderBottom: '1px solid #e9ecef',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <div>
            <h2
              style={{ margin: '0 0 0.25rem 0', fontSize: '1.25rem', fontWeight: 'bold' }}
            >
              Edit Post
            </h2>
            <p style={{ margin: 0, fontSize: '0.875rem', color: '#6c757d' }}>
              ID: {post.id} • Created: {new Date(post.createdAt).toLocaleDateString()}
            </p>
          </div>

          <Form method="post" style={{ display: 'inline' }}>
            <input type="hidden" name="intent" value="delete" />
            <button
              type="submit"
              onClick={e => {
                if (
                  !confirm(
                    'Are you sure you want to delete this post? This action cannot be undone.'
                  )
                ) {
                  e.preventDefault();
                }
              }}
              style={{
                padding: '0.5rem 1rem',
                backgroundColor: '#dc3545',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '0.875rem',
                fontWeight: '500',
              }}
            >
              🗑️ Delete Post
            </button>
          </Form>
        </div>

        <Form method="post" style={{ padding: '1.5rem' }}>
          {/* Tab Navigation */}
          <div
            style={{
              display: 'flex',
              borderBottom: '1px solid #e9ecef',
              marginBottom: '2rem',
            }}
          >
            <button
              type="button"
              onClick={() => setActiveTab('main')}
              style={{
                padding: '0.75rem 1rem',
                border: 'none',
                borderBottom:
                  activeTab === 'main' ? '2px solid #007bff' : '2px solid transparent',
                backgroundColor: activeTab === 'main' ? '#f8f9fa' : 'transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: activeTab === 'main' ? 'bold' : 'normal',
              }}
            >
              ⚙️ Main Settings
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('en')}
              style={{
                padding: '0.75rem 1rem',
                border: 'none',
                borderBottom:
                  activeTab === 'en' ? '2px solid #007bff' : '2px solid transparent',
                backgroundColor: activeTab === 'en' ? '#f8f9fa' : 'transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: activeTab === 'en' ? 'bold' : 'normal',
              }}
            >
              🇺🇸 English
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('it')}
              style={{
                padding: '0.75rem 1rem',
                border: 'none',
                borderBottom:
                  activeTab === 'it' ? '2px solid #007bff' : '2px solid transparent',
                backgroundColor: activeTab === 'it' ? '#f8f9fa' : 'transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: activeTab === 'it' ? 'bold' : 'normal',
              }}
            >
              🇮🇹 Italiano
            </button>
          </div>

          {/* Main Settings Tab */}
          <div style={{ display: activeTab === 'main' ? 'grid' : 'none', gap: '1.5rem' }}>
            <div
              style={{ display: 'grid', gridTemplateColumns: '1fr 200px', gap: '1rem' }}
            >
              <div>
                <label
                  htmlFor="slug"
                  style={{
                    display: 'block',
                    marginBottom: '0.5rem',
                    fontWeight: 'bold',
                    color: '#374151',
                  }}
                >
                  Post Slug (URL) *
                </label>
                <input
                  type="text"
                  id="slug"
                  name="slug"
                  required
                  defaultValue={post.slug}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    fontSize: '1rem',
                  }}
                  placeholder="my-awesome-post"
                />
              </div>

              <div>
                <label
                  htmlFor="status"
                  style={{
                    display: 'block',
                    marginBottom: '0.5rem',
                    fontWeight: 'bold',
                    color: '#374151',
                  }}
                >
                  Status
                </label>
                <select
                  id="status"
                  name="status"
                  defaultValue={post.status}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    fontSize: '1rem',
                  }}
                >
                  <option value="DRAFT">Draft</option>
                  <option value="PUBLISHED">Published</option>
                  <option value="ARCHIVED">Archived</option>
                </select>
              </div>
            </div>

            {/* Banner Selection */}
            <div>
              <p
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Banner Image
              </p>
              <input type="hidden" name="banner" value={selectedBanner} />

              {selectedBanner && (
                <div style={{ marginBottom: '1rem' }}>
                  <img
                    src={selectedBanner}
                    alt="Selected banner"
                    style={{
                      width: '300px',
                      height: '150px',
                      objectFit: 'cover',
                      borderRadius: '6px',
                      border: '1px solid #d1d5db',
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setSelectedBanner('')}
                    style={{
                      marginLeft: '0.5rem',
                      padding: '0.25rem 0.5rem',
                      fontSize: '0.75rem',
                      backgroundColor: '#dc3545',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                    }}
                  >
                    Remove
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => setShowGallery(!showGallery)}
                style={{
                  padding: '0.5rem 1rem',
                  backgroundColor: showGallery ? '#6c757d' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                {showGallery ? 'Hide Gallery' : 'Select Banner'}
              </button>

              {showGallery && (
                <div
                  style={{
                    marginTop: '1rem',
                    padding: '1rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                  }}
                >
                  <ImageGallery
                    images={galleryImages}
                    selectedImage={selectedBanner}
                    onImageSelect={url => {
                      setSelectedBanner(url);
                      setShowGallery(false);
                    }}
                    onImageUpload={imageData => {
                      setGalleryImages([imageData, ...galleryImages]);
                    }}
                    onImageDelete={filename => {
                      setGalleryImages(
                        galleryImages.filter(img => img.filename !== filename)
                      );
                      if (selectedBanner.includes(filename)) {
                        setSelectedBanner('');
                      }
                    }}
                    allowUpload={true}
                    allowDelete={true}
                    className="edit-post-gallery"
                  />
                </div>
              )}
            </div>

            <div>
              <label
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                  cursor: 'pointer',
                }}
              >
                <input
                  type="checkbox"
                  name="featured"
                  defaultChecked={post.featured}
                  style={{ width: '18px', height: '18px' }}
                />
                Featured Post
              </label>
            </div>
          </div>

          {/* English Tab */}
          <div style={{ display: activeTab === 'en' ? 'grid' : 'none', gap: '1.5rem' }}>
            <div>
              <label
                htmlFor="slugEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                English Slug (Optional)
              </label>
              <input
                type="text"
                id="slugEn"
                name="slugEn"
                defaultValue={englishTranslation?.slug || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
                placeholder="Leave empty to use main slug"
              />
            </div>

            <div>
              <label
                htmlFor="titleEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Title (English) *
              </label>
              <input
                type="text"
                id="titleEn"
                name="titleEn"
                required
                defaultValue={englishTranslation?.title || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
              />
            </div>

            <div>
              <label
                htmlFor="abstractEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Abstract (English) *
              </label>
              <textarea
                id="abstractEn"
                name="abstractEn"
                required
                rows={4}
                defaultValue={englishTranslation?.abstract || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'inherit',
                  resize: 'vertical',
                }}
              />
            </div>

            <div>
              <label
                htmlFor="contentEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Content (English) *
              </label>
              <textarea
                id="contentEn"
                name="contentEn"
                required
                rows={20}
                defaultValue={englishTranslation?.content || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                  resize: 'vertical',
                }}
              />
            </div>
          </div>

          {/* Italian Tab */}
          <div style={{ display: activeTab === 'it' ? 'grid' : 'none', gap: '1.5rem' }}>
            <div>
              <label
                htmlFor="slugIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Slug Italiano (Opzionale)
              </label>
              <input
                type="text"
                id="slugIt"
                name="slugIt"
                defaultValue={italianTranslation?.slug || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
                placeholder="Lascia vuoto per usare lo slug principale"
              />
            </div>

            <div>
              <label
                htmlFor="titleIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Titolo (Italiano)
              </label>
              <input
                type="text"
                id="titleIt"
                name="titleIt"
                defaultValue={italianTranslation?.title || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
              />
            </div>

            <div>
              <label
                htmlFor="abstractIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Riassunto (Italiano)
              </label>
              <textarea
                id="abstractIt"
                name="abstractIt"
                rows={4}
                defaultValue={italianTranslation?.abstract || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'inherit',
                  resize: 'vertical',
                }}
              />
            </div>

            <div>
              <label
                htmlFor="contentIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Contenuto (Italiano)
              </label>
              <textarea
                id="contentIt"
                name="contentIt"
                rows={20}
                defaultValue={italianTranslation?.content || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                  resize: 'vertical',
                }}
              />
            </div>
          </div>

          {/* Form Actions */}
          <div
            style={{
              marginTop: '2rem',
              paddingTop: '2rem',
              borderTop: '1px solid #e9ecef',
              display: 'flex',
              gap: '1rem',
              justifyContent: 'flex-end',
            }}
          >
            <button
              type="button"
              onClick={() => window.history.back()}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: '#6c757d',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '1rem',
                fontWeight: '500',
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: isSubmitting ? '#6c757d' : '#007bff',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: isSubmitting ? 'not-allowed' : 'pointer',
                fontSize: '1rem',
                fontWeight: '500',
              }}
            >
              {isSubmitting ? 'Updating Post...' : 'Update Post'}
            </button>
          </div>
        </Form>
      </div>
    </AdminLayout>
  );
}
