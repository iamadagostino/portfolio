export { VolkiharKnight as default, meta } from './volkihar-knight';
