import type { LoaderFunctionArgs, ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

// Import the existing contact components and functions
import Contact, {
  loader as contactLoader,
  action as contactAction,
} from './$lang.contact';

// Reuse contact logic for localized "contatti" URLs
export const loader = async (args: LoaderFunctionArgs) => {
  const { params } = args;
  const language = returnLanguageIfSupported(params.lang);

  // If language is not supported, redirect to root
  if (!language) {
    throw redirect('/');
  }

  // Only allow Italian language for "contatti" route
  if (language !== 'it') {
    throw redirect(`/${language}/contact`);
  }

  // Reuse existing contact loader
  return contactLoader(args);
};

export const action = async (args: ActionFunctionArgs) => {
  const { params } = args;
  const language = returnLanguageIfSupported(params.lang);

  // Only allow Italian language for "contatti" route
  if (language !== 'it') {
    throw redirect(`/${language}/contact`);
  }

  // Reuse existing contact action
  return contactAction(args);
};

export default Contact;

export const meta = () => {
  return [
    { title: 'Contatti' },
    {
      name: 'description',
      content:
        'Mettiti in contatto per discutere di progetti, collaborazioni o semplicemente per dire ciao.',
    },
  ];
};

export const handle = {
  i18n: ['contact', 'common'],
};
