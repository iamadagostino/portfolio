import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { getBlogPostsWithCache } from '~/services/blog.server';
import { Articles } from './articles_._index/articles';

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  // If language is not supported, redirect to root and let it auto-detect
  if (!language) {
    throw redirect('/');
  }

  try {
    // Load posts from database with caching (will automatically use Accelerate if available)
    const allPosts = await getBlogPostsWithCache(language);
    const featured = allPosts.find(post => post.featured);
    const posts = allPosts.filter(post => post.slug !== featured?.slug);

    // Combine with language data
    return { posts, featured, lang: language };
  } catch (error) {
    console.error('Error loading articles:', error);
    // Return empty data instead of throwing error to prevent complete page failure
    return { posts: [], featured: null, lang: language };
  }
};

export default Articles;

export const meta = () => {
  return [
    { title: 'Articles' },
    {
      name: 'description',
      content: 'A collection of technical design and development articles.',
    },
  ];
};

export const handle = {
  i18n: ['articles', 'common'],
};
