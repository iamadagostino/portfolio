export { Home as default, meta, links } from './home/home';
