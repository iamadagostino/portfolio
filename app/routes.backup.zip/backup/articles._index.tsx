import { redirect } from '@remix-run/cloudflare';

export const loader = async () => {
  // Redirect to English articles by default
  // You can add logic here to detect user's preferred language
  throw redirect('/en/articles');
};

// This component should never render due to the redirect
export default function ArticlesRedirect() {
  return null;
}
