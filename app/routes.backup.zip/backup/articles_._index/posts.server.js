import { formatTimecode } from '../../utils/timecode.js';
import { getUrlSlugFromContent } from '../../utils/article-slugs.js';

export async function getPosts(lang = 'en') {
  const modules = import.meta.glob('../articles/*.mdx', { eager: true });

  const posts = await Promise.all(
    Object.entries(modules).map(async ([file, post]) => {
      // Extract just the article name from the file path (e.g., "hello-world" from "../articles/hello-world.mdx")
      const contentSlug = file.replace('../articles/', '').replace('.mdx', '');
      
      // Skip language-specific files (e.g., hello-world.it.mdx) as they're handled separately
      if (contentSlug.includes('.')) {
        return null;
      }
      
      // Try to load localized version first, then fallback to default
      let localizedPost = null;
      let selectedFrontmatter = post.frontmatter || post.meta;
      
      // Check if there's a localized version for this language
      const localizedKey = `../articles/${contentSlug}.${lang}.mdx`;
      if (modules[localizedKey]) {
        localizedPost = modules[localizedKey];
        selectedFrontmatter = localizedPost.frontmatter || localizedPost.meta;
      }
      
      // Calculate realistic reading time based on known article lengths
      let readTime = 5; // Default 5 minutes
      
      // Assign specific reading times based on content slug and actual word counts
      const readingTimes = {
        'hello-world': 5, // ~1140 words ≈ 5 minutes
        'modern-styling-in-react': 8, // ~1776 words ≈ 8 minutes
      };
      
      readTime = readingTimes[contentSlug] || 5;
      
      const timecode = formatTimecode(readTime * 60 * 1000); // Convert minutes to milliseconds

      // Get the URL slug for the specified language
      const urlSlug = getUrlSlugFromContent(contentSlug, lang);

      return {
        slug: urlSlug, // Use the localized URL slug
        contentSlug, // Keep the content slug for internal reference
        timecode,
        readTime,
        frontmatter: selectedFrontmatter, // Use localized frontmatter if available
      };
    })
  );

  // Filter out null entries (language-specific files)
  const validPosts = posts.filter(post => post !== null);

  return sortBy(validPosts, post => post.frontmatter?.date || new Date(), 'desc');
}

function sortBy(arr, key, dir = 'asc') {
  return arr.sort((a, b) => {
    const res = compare(key(a), key(b));
    return dir === 'asc' ? res : -res;
  });
}

function compare(a, b) {
  if (a < b) return -1;
  if (a > b) return 1;
  return 0;
}