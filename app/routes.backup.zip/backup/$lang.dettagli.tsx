import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

// Details are typically shown on the home page, so redirect there with anchor
export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  // If language is not supported, redirect to root
  if (!language) {
    throw redirect('/');
  }

  // Only allow Italian language for "dettagli" route
  if (language !== 'it') {
    throw redirect(`/${language}/details`);
  }

  // Redirect to home page with details anchor
  throw redirect(`/${language}#details`);
};
