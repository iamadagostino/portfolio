import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { useLoaderData, Link } from '@remix-run/react';
import { prisma } from '~/.server/db';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { requireAdminUser } from '~/services/admin-auth.server';
import { AdminLayout } from '~/layouts/admin';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  try {
    // Get all posts with their translations and author info
    const posts = await prisma.post.findMany({
      include: {
        author: {
          select: { username: true, firstName: true, lastName: true },
        },
        translations: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return { posts, language };
  } catch (error) {
    console.error('Posts loader error:', error);
    throw new Response('Failed to load posts', { status: 500 });
  }
};

export default function AdminPosts() {
  const { posts, language } = useLoaderData<typeof loader>();

  // Consistent date formatter
  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleDateString(language === 'it' ? 'it-IT' : 'en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getPostTitle = (post: (typeof posts)[number]) => {
    return (
      post.translations.find(t => t.language === 'EN')?.title ||
      post.translations[0]?.title ||
      post.slug
    );
  };

  const getPostAbstract = (post: (typeof posts)[number]) => {
    return (
      post.translations.find(t => t.language === 'EN')?.abstract ||
      post.translations[0]?.abstract ||
      'No abstract available'
    );
  };

  return (
    <AdminLayout
      title="Posts"
      subtitle="Manage your blog posts"
      actions={
        <Link
          to={`/${language}/admin/posts/create`}
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: '#28a745',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '6px',
            fontSize: '1rem',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
          }}
        >
          ➕ New Post
        </Link>
      }
    >
      {/* Stats Cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1rem',
          marginBottom: '2rem',
        }}
      >
        <div
          style={{
            background: 'white',
            padding: '1.5rem',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            border: '1px solid #e9ecef',
          }}
        >
          <h3
            style={{
              margin: '0 0 0.5rem 0',
              color: '#6c757d',
              fontSize: '0.875rem',
              textTransform: 'uppercase',
            }}
          >
            Total Posts
          </h3>
          <p
            style={{ margin: 0, fontSize: '2rem', fontWeight: 'bold', color: '#007bff' }}
          >
            {posts.length}
          </p>
        </div>

        <div
          style={{
            background: 'white',
            padding: '1.5rem',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            border: '1px solid #e9ecef',
          }}
        >
          <h3
            style={{
              margin: '0 0 0.5rem 0',
              color: '#6c757d',
              fontSize: '0.875rem',
              textTransform: 'uppercase',
            }}
          >
            Published
          </h3>
          <p
            style={{ margin: 0, fontSize: '2rem', fontWeight: 'bold', color: '#28a745' }}
          >
            {posts.filter(p => p.status === 'PUBLISHED').length}
          </p>
        </div>

        <div
          style={{
            background: 'white',
            padding: '1.5rem',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            border: '1px solid #e9ecef',
          }}
        >
          <h3
            style={{
              margin: '0 0 0.5rem 0',
              color: '#6c757d',
              fontSize: '0.875rem',
              textTransform: 'uppercase',
            }}
          >
            Drafts
          </h3>
          <p
            style={{ margin: 0, fontSize: '2rem', fontWeight: 'bold', color: '#ffc107' }}
          >
            {posts.filter(p => p.status === 'DRAFT').length}
          </p>
        </div>

        <div
          style={{
            background: 'white',
            padding: '1.5rem',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            border: '1px solid #e9ecef',
          }}
        >
          <h3
            style={{
              margin: '0 0 0.5rem 0',
              color: '#6c757d',
              fontSize: '0.875rem',
              textTransform: 'uppercase',
            }}
          >
            Featured
          </h3>
          <p
            style={{ margin: 0, fontSize: '2rem', fontWeight: 'bold', color: '#17a2b8' }}
          >
            {posts.filter(p => p.featured).length}
          </p>
        </div>
      </div>

      {/* Posts List */}
      <div
        style={{
          background: 'white',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        }}
      >
        <div
          style={{
            padding: '1.5rem',
            borderBottom: '1px solid #e9ecef',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 'bold' }}>
            All Posts ({posts.length})
          </h2>
        </div>

        {posts.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: '#6c757d' }}>
            <p style={{ fontSize: '1.125rem', marginBottom: '1rem' }}>No posts found</p>
            <p>Create your first post to get started!</p>
            <Link
              to={`/${language}/admin/posts/create`}
              style={{
                display: 'inline-block',
                marginTop: '1rem',
                padding: '0.75rem 1.5rem',
                backgroundColor: '#007bff',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                fontWeight: 'bold',
              }}
            >
              Create First Post
            </Link>
          </div>
        ) : (
          <div style={{ padding: '0' }}>
            {posts.map((post, index) => (
              <div
                key={post.id}
                style={{
                  padding: '1.5rem',
                  borderBottom: index < posts.length - 1 ? '1px solid #f8f9fa' : 'none',
                  transition: 'background-color 0.15s ease-in-out',
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLDivElement).style.backgroundColor = '#f8f9fa';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLDivElement).style.backgroundColor =
                    'transparent';
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'start',
                  }}
                >
                  <div style={{ flex: 1, marginRight: '1rem' }}>
                    {/* Title and status */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        marginBottom: '0.5rem',
                      }}
                    >
                      <h3 style={{ margin: 0, fontSize: '1.125rem', fontWeight: '600' }}>
                        <Link
                          to={`/${language}/articles/${post.slug}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ color: '#2c3e50', textDecoration: 'none' }}
                        >
                          {getPostTitle(post)}
                        </Link>
                      </h3>
                      <span
                        style={{
                          padding: '0.25rem 0.5rem',
                          fontSize: '0.75rem',
                          fontWeight: 'bold',
                          textTransform: 'uppercase',
                          borderRadius: '4px',
                          backgroundColor:
                            post.status === 'PUBLISHED'
                              ? '#d4edda'
                              : post.status === 'DRAFT'
                              ? '#fff3cd'
                              : '#f8d7da',
                          color:
                            post.status === 'PUBLISHED'
                              ? '#155724'
                              : post.status === 'DRAFT'
                              ? '#856404'
                              : '#721c24',
                        }}
                      >
                        {post.status}
                      </span>
                      {post.featured && (
                        <span
                          style={{
                            padding: '0.25rem 0.5rem',
                            fontSize: '0.75rem',
                            fontWeight: 'bold',
                            backgroundColor: '#bee5eb',
                            color: '#0c5460',
                            borderRadius: '4px',
                          }}
                        >
                          ⭐ FEATURED
                        </span>
                      )}
                    </div>

                    {/* Abstract */}
                    <p
                      style={{
                        margin: '0 0 0.75rem 0',
                        color: '#6c757d',
                        lineHeight: '1.5',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {getPostAbstract(post)}
                    </p>

                    {/* Meta info */}
                    <div
                      style={{
                        display: 'flex',
                        gap: '1rem',
                        fontSize: '0.875rem',
                        color: '#adb5bd',
                      }}
                    >
                      <span>
                        Slug: <code style={{ color: '#6c757d' }}>{post.slug}</code>
                      </span>
                      <span>
                        Languages: {post.translations.map(t => t.language).join(', ')}
                      </span>
                      <span>Created: {formatDate(post.createdAt)}</span>
                      {post.readTime && <span>Read time: {post.readTime}m</span>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', gap: '0.5rem', flexShrink: 0 }}>
                    <Link
                      to={`/${language}/admin/posts/${post.id}/edit`}
                      style={{
                        padding: '0.5rem 1rem',
                        backgroundColor: '#007bff',
                        color: 'white',
                        textDecoration: 'none',
                        borderRadius: '4px',
                        fontSize: '0.875rem',
                        fontWeight: '500',
                      }}
                    >
                      ✏️ Edit
                    </Link>
                    <Link
                      to={`/${language}/admin/posts/${post.id}/delete`}
                      style={{
                        padding: '0.5rem 1rem',
                        backgroundColor: '#dc3545',
                        color: 'white',
                        textDecoration: 'none',
                        borderRadius: '4px',
                        fontSize: '0.875rem',
                        fontWeight: '500',
                      }}
                    >
                      🗑️ Delete
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
