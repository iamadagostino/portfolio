import type { LoaderFunctionArgs, ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { Form, useActionData, useNavigation, useLoaderData } from '@remix-run/react';
import { useState } from 'react';
import { prisma } from '~/.server/db';
import { getGalleryImages } from '~/services/upload.server';
import { ImageGallery, type ImageData } from '~/components/image-gallery';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { requireAdminUser } from '~/services/admin-auth.server';
import { AdminLayout } from '~/layouts/admin';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  try {
    // Get gallery images for banner selection
    const galleryImages = await getGalleryImages();
    const images: ImageData[] = galleryImages.map(img => ({
      ...img,
      createdAt: img.createdAt.toISOString(),
    }));

    return { images, language };
  } catch (error) {
    console.error('Create post loader error:', error);
    throw new Response('Failed to load create post page', { status: 500 });
  }
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  const formData = await request.formData();

  const slug = (formData.get('slug') as string) || '';
  const slugEn = (formData.get('slugEn') as string) || '';
  const slugIt = (formData.get('slugIt') as string) || '';
  const titleEn = (formData.get('titleEn') as string) || '';
  const titleIt = (formData.get('titleIt') as string) || '';
  const abstractEn = (formData.get('abstractEn') as string) || '';
  const abstractIt = (formData.get('abstractIt') as string) || '';
  const contentEn = (formData.get('contentEn') as string) || '';
  const contentIt = (formData.get('contentIt') as string) || '';
  const featured = formData.get('featured') === 'on';
  const banner = (formData.get('banner') as string) || '';
  const status = (formData.get('status') as string) || 'DRAFT';

  // Validate required fields
  if (!slug || !titleEn || !abstractEn || !contentEn) {
    return {
      error: 'Missing required fields: slug, titleEn, abstractEn, contentEn',
      values: {
        slug,
        slugEn,
        slugIt,
        titleEn,
        titleIt,
        abstractEn,
        abstractIt,
        contentEn,
        contentIt,
        featured,
        banner,
        status,
      },
    };
  }

  try {
    // Check if slug already exists
    const existingPost = await prisma.post.findUnique({
      where: { slug },
    });

    if (existingPost) {
      return {
        error: 'A post with this slug already exists. Please use a different slug.',
        values: {
          slug,
          slugEn,
          slugIt,
          titleEn,
          titleIt,
          abstractEn,
          abstractIt,
          contentEn,
          contentIt,
          featured,
          banner,
          status,
        },
      };
    }

    // Get admin user (we already verified they're authenticated)
    const adminUser = await prisma.user.findFirst({
      where: { role: 'ADMIN' },
    });

    if (!adminUser) {
      return {
        error: 'Admin user not found',
        values: {
          slug,
          slugEn,
          slugIt,
          titleEn,
          titleIt,
          abstractEn,
          abstractIt,
          contentEn,
          contentIt,
          featured,
          banner,
          status,
        },
      };
    }

    // Create post with translations
    await prisma.post.create({
      data: {
        slug,
        status: status as 'DRAFT' | 'PUBLISHED' | 'ARCHIVED',
        featured,
        banner: banner || null,
        readTime: Math.ceil(contentEn.split(' ').length / 200),
        authorId: adminUser.id,
        publishedAt: status === 'PUBLISHED' ? new Date() : null,
        translations: {
          create: [
            {
              language: 'EN',
              title: titleEn,
              abstract: abstractEn,
              content: contentEn,
              slug: slugEn && slugEn !== slug ? slugEn : null,
              metaTitle: `${titleEn} - Angelo D'Agostino`,
              metaDescription: abstractEn,
            },
            ...(titleIt && contentIt
              ? [
                  {
                    language: 'IT' as const,
                    title: titleIt,
                    abstract: abstractIt || abstractEn,
                    content: contentIt,
                    slug: slugIt && slugIt !== slug ? slugIt : null,
                    metaTitle: `${titleIt} - Angelo D'Agostino`,
                    metaDescription: abstractIt || abstractEn,
                  },
                ]
              : []),
          ],
        },
      },
    });

    return redirect(`/${language}/admin/posts`);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      error: `Failed to create post: ${message}`,
      values: {
        slug,
        slugEn,
        slugIt,
        titleEn,
        titleIt,
        abstractEn,
        abstractIt,
        contentEn,
        contentIt,
        featured,
        banner,
        status,
      },
    };
  }
};

export default function CreatePost() {
  const { images } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();
  const isSubmitting = navigation.state === 'submitting';

  // Form state
  const [selectedBanner, setSelectedBanner] = useState<string>(
    actionData?.values?.banner || ''
  );
  const [galleryImages, setGalleryImages] = useState<ImageData[]>(images);
  const [showGallery, setShowGallery] = useState(false);
  const [activeTab, setActiveTab] = useState<'main' | 'en' | 'it'>('main');

  return (
    <AdminLayout
      title="Create New Post"
      subtitle="Create a new blog post with multi-language support"
    >
      {actionData?.error && (
        <div
          style={{
            padding: '1rem',
            backgroundColor: '#f8d7da',
            color: '#721c24',
            borderRadius: '6px',
            marginBottom: '2rem',
            border: '1px solid #f5c6cb',
          }}
        >
          <strong>Error:</strong> {actionData.error}
        </div>
      )}

      <div
        style={{
          background: 'white',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        }}
      >
        <div style={{ padding: '1.5rem', borderBottom: '1px solid #e9ecef' }}>
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 'bold' }}>
            Post Details
          </h2>
        </div>

        <Form method="post" style={{ padding: '1.5rem' }}>
          {/* Tab Navigation */}
          <div
            style={{
              display: 'flex',
              borderBottom: '1px solid #e9ecef',
              marginBottom: '2rem',
            }}
          >
            <button
              type="button"
              onClick={() => setActiveTab('main')}
              style={{
                padding: '0.75rem 1rem',
                border: 'none',
                borderBottom:
                  activeTab === 'main' ? '2px solid #007bff' : '2px solid transparent',
                backgroundColor: activeTab === 'main' ? '#f8f9fa' : 'transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: activeTab === 'main' ? 'bold' : 'normal',
              }}
            >
              ⚙️ Main Settings
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('en')}
              style={{
                padding: '0.75rem 1rem',
                border: 'none',
                borderBottom:
                  activeTab === 'en' ? '2px solid #007bff' : '2px solid transparent',
                backgroundColor: activeTab === 'en' ? '#f8f9fa' : 'transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: activeTab === 'en' ? 'bold' : 'normal',
              }}
            >
              🇺🇸 English
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('it')}
              style={{
                padding: '0.75rem 1rem',
                border: 'none',
                borderBottom:
                  activeTab === 'it' ? '2px solid #007bff' : '2px solid transparent',
                backgroundColor: activeTab === 'it' ? '#f8f9fa' : 'transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: activeTab === 'it' ? 'bold' : 'normal',
              }}
            >
              🇮🇹 Italiano
            </button>
          </div>

          {/* Main Settings Tab */}
          <div style={{ display: activeTab === 'main' ? 'grid' : 'none', gap: '1.5rem' }}>
            <div
              style={{ display: 'grid', gridTemplateColumns: '1fr 200px', gap: '1rem' }}
            >
              <div>
                <label
                  htmlFor="slug"
                  style={{
                    display: 'block',
                    marginBottom: '0.5rem',
                    fontWeight: 'bold',
                    color: '#374151',
                  }}
                >
                  Post Slug (URL) *
                </label>
                <input
                  type="text"
                  id="slug"
                  name="slug"
                  required
                  defaultValue={actionData?.values?.slug || ''}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    fontSize: '1rem',
                  }}
                  placeholder="my-awesome-post"
                />
                <p
                  style={{
                    fontSize: '0.875rem',
                    color: '#6c757d',
                    margin: '0.25rem 0 0 0',
                  }}
                >
                  This will be used in the URL: /articles/your-slug
                </p>
              </div>

              <div>
                <label
                  htmlFor="status"
                  style={{
                    display: 'block',
                    marginBottom: '0.5rem',
                    fontWeight: 'bold',
                    color: '#374151',
                  }}
                >
                  Status
                </label>
                <select
                  id="status"
                  name="status"
                  defaultValue={actionData?.values?.status || 'DRAFT'}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    fontSize: '1rem',
                  }}
                >
                  <option value="DRAFT">Draft</option>
                  <option value="PUBLISHED">Published</option>
                  <option value="ARCHIVED">Archived</option>
                </select>
              </div>
            </div>

            {/* Banner Selection */}
            <div>
              <p
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Banner Image
              </p>
              <input type="hidden" name="banner" value={selectedBanner} />

              {selectedBanner && (
                <div style={{ marginBottom: '1rem' }}>
                  <img
                    src={selectedBanner}
                    alt="Selected banner"
                    style={{
                      width: '300px',
                      height: '150px',
                      objectFit: 'cover',
                      borderRadius: '6px',
                      border: '1px solid #d1d5db',
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setSelectedBanner('')}
                    style={{
                      marginLeft: '0.5rem',
                      padding: '0.25rem 0.5rem',
                      fontSize: '0.75rem',
                      backgroundColor: '#dc3545',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                    }}
                  >
                    Remove
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => setShowGallery(!showGallery)}
                style={{
                  padding: '0.5rem 1rem',
                  backgroundColor: showGallery ? '#6c757d' : '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                {showGallery ? 'Hide Gallery' : 'Select Banner'}
              </button>

              {showGallery && (
                <div
                  style={{
                    marginTop: '1rem',
                    padding: '1rem',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                  }}
                >
                  <ImageGallery
                    images={galleryImages}
                    selectedImage={selectedBanner}
                    onImageSelect={url => {
                      setSelectedBanner(url);
                      setShowGallery(false);
                    }}
                    onImageUpload={imageData => {
                      setGalleryImages([imageData, ...galleryImages]);
                    }}
                    onImageDelete={filename => {
                      setGalleryImages(
                        galleryImages.filter(img => img.filename !== filename)
                      );
                      if (selectedBanner.includes(filename)) {
                        setSelectedBanner('');
                      }
                    }}
                    allowUpload={true}
                    allowDelete={true}
                    className="create-post-gallery"
                  />
                </div>
              )}
            </div>

            <div>
              <label
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                  cursor: 'pointer',
                }}
              >
                <input
                  type="checkbox"
                  name="featured"
                  defaultChecked={actionData?.values?.featured || false}
                  style={{ width: '18px', height: '18px' }}
                />
                Featured Post
              </label>
              <p
                style={{
                  fontSize: '0.875rem',
                  color: '#6c757d',
                  margin: '0.25rem 0 0 0',
                }}
              >
                Featured posts will be highlighted on the articles page
              </p>
            </div>
          </div>

          {/* English Tab */}
          <div style={{ display: activeTab === 'en' ? 'grid' : 'none', gap: '1.5rem' }}>
            <div>
              <label
                htmlFor="slugEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                English Slug (Optional)
              </label>
              <input
                type="text"
                id="slugEn"
                name="slugEn"
                defaultValue={actionData?.values?.slugEn || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
                placeholder="Leave empty to use main slug"
              />
            </div>

            <div>
              <label
                htmlFor="titleEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Title (English) *
              </label>
              <input
                type="text"
                id="titleEn"
                name="titleEn"
                required
                defaultValue={actionData?.values?.titleEn || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
                placeholder="Your amazing blog post title"
              />
            </div>

            <div>
              <label
                htmlFor="abstractEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Abstract (English) *
              </label>
              <textarea
                id="abstractEn"
                name="abstractEn"
                required
                rows={4}
                defaultValue={actionData?.values?.abstractEn || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'inherit',
                  resize: 'vertical',
                }}
                placeholder="A brief description of your post..."
              />
            </div>

            <div>
              <label
                htmlFor="contentEn"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Content (English) *
              </label>
              <textarea
                id="contentEn"
                name="contentEn"
                required
                rows={20}
                defaultValue={actionData?.values?.contentEn || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                  resize: 'vertical',
                }}
                placeholder="Write your post content in Markdown..."
              />
              <p
                style={{
                  fontSize: '0.875rem',
                  color: '#6c757d',
                  margin: '0.25rem 0 0 0',
                }}
              >
                You can use Markdown syntax for formatting
              </p>
            </div>
          </div>

          {/* Italian Tab */}
          <div style={{ display: activeTab === 'it' ? 'grid' : 'none', gap: '1.5rem' }}>
            <div>
              <label
                htmlFor="slugIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Slug Italiano (Opzionale)
              </label>
              <input
                type="text"
                id="slugIt"
                name="slugIt"
                defaultValue={actionData?.values?.slugIt || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
                placeholder="Lascia vuoto per usare lo slug principale"
              />
            </div>

            <div>
              <label
                htmlFor="titleIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Titolo (Italiano)
              </label>
              <input
                type="text"
                id="titleIt"
                name="titleIt"
                defaultValue={actionData?.values?.titleIt || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}
                placeholder="Il titolo del tuo fantastico post"
              />
            </div>

            <div>
              <label
                htmlFor="abstractIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Riassunto (Italiano)
              </label>
              <textarea
                id="abstractIt"
                name="abstractIt"
                rows={4}
                defaultValue={actionData?.values?.abstractIt || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'inherit',
                  resize: 'vertical',
                }}
                placeholder="Una breve descrizione del tuo post..."
              />
            </div>

            <div>
              <label
                htmlFor="contentIt"
                style={{
                  display: 'block',
                  marginBottom: '0.5rem',
                  fontWeight: 'bold',
                  color: '#374151',
                }}
              >
                Contenuto (Italiano)
              </label>
              <textarea
                id="contentIt"
                name="contentIt"
                rows={20}
                defaultValue={actionData?.values?.contentIt || ''}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '1rem',
                  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                  resize: 'vertical',
                }}
                placeholder="Scrivi il contenuto del post in Markdown..."
              />
              <p
                style={{
                  fontSize: '0.875rem',
                  color: '#6c757d',
                  margin: '0.25rem 0 0 0',
                }}
              >
                Puoi usare la sintassi Markdown per la formattazione
              </p>
            </div>
          </div>

          {/* Form Actions */}
          <div
            style={{
              marginTop: '2rem',
              paddingTop: '2rem',
              borderTop: '1px solid #e9ecef',
              display: 'flex',
              gap: '1rem',
              justifyContent: 'flex-end',
            }}
          >
            <button
              type="button"
              onClick={() => window.history.back()}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: '#6c757d',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '1rem',
                fontWeight: '500',
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              style={{
                padding: '0.75rem 1.5rem',
                backgroundColor: isSubmitting ? '#6c757d' : '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: isSubmitting ? 'not-allowed' : 'pointer',
                fontSize: '1rem',
                fontWeight: '500',
              }}
            >
              {isSubmitting ? 'Creating Post...' : 'Create Post'}
            </button>
          </div>
        </Form>
      </div>
    </AdminLayout>
  );
}
