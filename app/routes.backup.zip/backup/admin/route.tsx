import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { json } from '@remix-run/cloudflare';
import { Outlet, useLoaderData } from '@remix-run/react';
import { requireAdminUser } from '~/services/admin-auth.server';

// Import admin CSS
import '../../../admin/assets/css/app.css';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  await requireAdminUser(request);

  return json({
    user: {
      name: "Angelo D'Agostino",
      role: 'Administrator',
    },
    lang: params.lang || 'en',
  });
};

export default function AdminLayout() {
  const { user, lang } = useLoaderData<typeof loader>();

  return (
    <div className="py-5 md:py-0 h-full">
      {/* Admin content will be loaded here */}
      <div className="flex h-full">
        {/* Sidebar */}
        <nav className="w-64 bg-slate-900 h-full flex flex-col">
          <div className="px-5 py-8">
            <div className="flex items-center mb-8">
              <div className="text-2xl font-bold text-white">AD</div>
              <span className="ml-3 text-lg font-semibold text-white">Admin</span>
            </div>

            <ul className="space-y-2">
              <li>
                <a
                  href={`/${lang}/admin/dashboard`}
                  className="flex items-center h-12 px-5 text-white bg-blue-600 rounded-xl mb-1"
                >
                  <div className="flex items-center justify-center w-5 h-5 mr-3">
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                      />
                    </svg>
                  </div>
                  <div>Dashboard</div>
                </a>
              </li>
              <li>
                <a
                  href={`/${lang}/admin/page-2`}
                  className="flex items-center h-12 px-5 text-slate-300 hover:bg-slate-800 rounded-xl mb-1 hover:text-white transition-colors"
                >
                  <div className="flex items-center justify-center w-5 h-5 mr-3">
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      />
                    </svg>
                  </div>
                  <div>Page 2</div>
                </a>
              </li>
            </ul>
          </div>
        </nav>

        {/* Main content */}
        <div className="flex-1 p-6 bg-gray-100">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900">Welcome, {user.name}</h1>
            <p className="text-gray-600">
              Manage your portfolio content and blog posts ({lang.toUpperCase()})
            </p>
          </div>

          {/* This will render the specific admin page content */}
          <Outlet />
        </div>
      </div>
    </div>
  );
}
