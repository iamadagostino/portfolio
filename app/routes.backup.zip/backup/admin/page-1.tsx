export default function AdminPage2() {
  return (
    <>
      <div className="intro-y flex items-center mt-8">
        <h2 className="text-lg font-medium mr-auto">Page 2</h2>
      </div>
      {/* BEGIN: Page Layout */}
      <div className="intro-y box p-5 mt-5">
        <p>This is example page 2 in the admin section.</p>
        <p>You can add any admin functionality here.</p>
      </div>
      {/* END: Page Layout */}
    </>
  );
}