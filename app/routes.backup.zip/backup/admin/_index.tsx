import { redirect, type LoaderFunctionArgs } from '@remix-run/cloudflare';

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const lang = params.lang || 'en';
  return redirect(`/${lang}/admin/dashboard`);
};
