export { SmartSparrow as default, meta } from './smart-sparrow';
