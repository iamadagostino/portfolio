import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

// This route handles the base /projects path, but we want individual project routes
// to work, so we'll only redirect if there's no specific project path
export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  // If language is not supported, redirect to root
  if (!language) {
    throw redirect('/');
  }

  // For now, redirect to home page with projects anchor
  // In the future, this could be a projects index page
  throw redirect(`/${language}#project-1`);
};
