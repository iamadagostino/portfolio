import type { ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { logout } from '~/services/admin-auth.server';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);
  const redirectTo = language ? `/${language}` : '/';

  return logout(request, redirectTo);
};

export const loader = async ({ params }: { params: { lang?: string } }) => {
  const language = returnLanguageIfSupported(params.lang);
  const redirectTo = language ? `/${language}` : '/';

  throw redirect(redirectTo);
};
