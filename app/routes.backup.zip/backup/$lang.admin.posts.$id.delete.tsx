import type { LoaderFunctionArgs, ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { Form, useLoaderData, useNavigation, Link } from '@remix-run/react';
import { prisma } from '~/.server/db';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { requireAdminUser } from '~/services/admin-auth.server';
import { AdminLayout } from '~/layouts/admin';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);
  const postId = params.id;

  if (!language || !postId) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  try {
    // Get the post with translations
    const post = await prisma.post.findUnique({
      where: { id: parseInt(postId) },
      include: {
        author: {
          select: { username: true, firstName: true, lastName: true },
        },
        translations: true,
      },
    });

    if (!post) {
      throw new Response('Post not found', { status: 404 });
    }

    return { post, language };
  } catch (error) {
    console.error('Delete post loader error:', error);
    throw new Response('Failed to load post', { status: 500 });
  }
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);
  const postId = params.id;

  if (!language || !postId) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  try {
    await prisma.post.delete({
      where: { id: parseInt(postId) },
    });

    return redirect(`/${language}/admin/posts`);
  } catch (error) {
    console.error('Delete post action error:', error);
    throw new Response('Failed to delete post', { status: 500 });
  }
};

export default function DeletePost() {
  const { post, language } = useLoaderData<typeof loader>();
  const navigation = useNavigation();
  const isSubmitting = navigation.state === 'submitting';

  const englishTranslation = post.translations.find(t => t.language === 'EN');
  const postTitle = englishTranslation?.title || post.slug;

  return (
    <AdminLayout title="Delete Post" subtitle="Confirm post deletion">
      <div
        style={{
          background: 'white',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          maxWidth: '600px',
          margin: '0 auto',
        }}
      >
        <div style={{ padding: '2rem', textAlign: 'center' }}>
          {/* Warning Icon */}
          <div
            style={{
              fontSize: '3rem',
              marginBottom: '1rem',
              color: '#dc3545',
            }}
          >
            ⚠️
          </div>

          <h2
            style={{
              margin: '0 0 1rem 0',
              fontSize: '1.5rem',
              fontWeight: 'bold',
              color: '#dc3545',
            }}
          >
            Delete Post
          </h2>

          <p
            style={{
              margin: '0 0 2rem 0',
              fontSize: '1.125rem',
              color: '#374151',
            }}
          >
            Are you sure you want to delete this post?
          </p>

          {/* Post Details */}
          <div
            style={{
              backgroundColor: '#f8f9fa',
              padding: '1.5rem',
              borderRadius: '8px',
              marginBottom: '2rem',
              textAlign: 'left',
            }}
          >
            <h3
              style={{
                margin: '0 0 1rem 0',
                fontSize: '1.25rem',
                fontWeight: 'bold',
                color: '#2c3e50',
              }}
            >
              {postTitle}
            </h3>

            <div
              style={{
                display: 'grid',
                gap: '0.5rem',
                fontSize: '0.875rem',
                color: '#6c757d',
              }}
            >
              <div>
                <strong>ID:</strong> {post.id}
              </div>
              <div>
                <strong>Slug:</strong> <code>{post.slug}</code>
              </div>
              <div>
                <strong>Status:</strong> {post.status}
              </div>
              <div>
                <strong>Languages:</strong>{' '}
                {post.translations.map(t => t.language).join(', ')}
              </div>
              <div>
                <strong>Created:</strong> {new Date(post.createdAt).toLocaleDateString()}
              </div>
              <div>
                <strong>Author:</strong> {post.author.firstName} {post.author.lastName}
              </div>
            </div>

            {englishTranslation?.abstract && (
              <div style={{ marginTop: '1rem' }}>
                <strong>Abstract:</strong>
                <p
                  style={{
                    margin: '0.5rem 0 0 0',
                    fontStyle: 'italic',
                    color: '#6c757d',
                  }}
                >
                  {englishTranslation.abstract}
                </p>
              </div>
            )}
          </div>

          {/* Warning Text */}
          <div
            style={{
              backgroundColor: '#fff3cd',
              border: '1px solid #ffeaa7',
              padding: '1rem',
              borderRadius: '6px',
              marginBottom: '2rem',
              color: '#856404',
              fontSize: '0.875rem',
            }}
          >
            <strong>⚠️ Warning:</strong> This action cannot be undone. The post and all
            its translations will be permanently deleted from the database.
          </div>

          {/* Action Buttons */}
          <div
            style={{
              display: 'flex',
              gap: '1rem',
              justifyContent: 'center',
              flexWrap: 'wrap',
            }}
          >
            <Link
              to={`/${language}/admin/posts`}
              style={{
                padding: '0.75rem 2rem',
                backgroundColor: '#6c757d',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                fontSize: '1rem',
                fontWeight: '500',
                display: 'inline-block',
              }}
            >
              Cancel
            </Link>

            <Link
              to={`/${language}/admin/posts/${post.id}/edit`}
              style={{
                padding: '0.75rem 2rem',
                backgroundColor: '#007bff',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                fontSize: '1rem',
                fontWeight: '500',
                display: 'inline-block',
              }}
            >
              ✏️ Edit Instead
            </Link>

            <Form method="post" style={{ display: 'inline' }}>
              <button
                type="submit"
                disabled={isSubmitting}
                style={{
                  padding: '0.75rem 2rem',
                  backgroundColor: isSubmitting ? '#6c757d' : '#dc3545',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: isSubmitting ? 'not-allowed' : 'pointer',
                  fontSize: '1rem',
                  fontWeight: '500',
                }}
              >
                {isSubmitting ? 'Deleting...' : '🗑️ Delete Post'}
              </button>
            </Form>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
