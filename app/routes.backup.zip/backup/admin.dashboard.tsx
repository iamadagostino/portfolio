import type { LoaderFunctionArgs, ActionFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';

// Simple admin check - in production you'd want proper authentication
const isAdmin = (request: Request) => {
  // For now, just check if it's localhost or has an admin cookie
  return (
    request.url.includes('localhost') ||
    request.headers.get('cookie')?.includes('admin=true')
  );
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
  if (!isAdmin(request)) {
    throw redirect('/');
  }

  // Detect preferred language and redirect to localized admin
  const acceptLanguage = request.headers.get('Accept-Language');
  const cookieHeader = request.headers.get('Cookie');

  // Check for i18n cookie first
  let preferredLang = 'en';
  if (cookieHeader) {
    const i18nMatch = cookieHeader.match(/i18n=([a-z]{2})/);
    if (i18nMatch) {
      preferredLang = i18nMatch[1];
    }
  }

  // Fallback to Accept-Language header
  if (preferredLang === 'en' && acceptLanguage) {
    if (acceptLanguage.includes('it') && !acceptLanguage.includes('en')) {
      preferredLang = 'it';
    }
  }

  // Redirect to localized admin dashboard
  const url = new URL(request.url);
  const searchParams = url.searchParams.toString();
  const redirectUrl = `/${preferredLang}/admin/dashboard${
    searchParams ? `?${searchParams}` : ''
  }`;

  throw redirect(redirectUrl);
};

export const action = async ({ request }: ActionFunctionArgs) => {
  if (!isAdmin(request)) {
    throw redirect('/');
  }

  // Detect language and redirect to localized admin
  const acceptLanguage = request.headers.get('Accept-Language');
  const cookieHeader = request.headers.get('Cookie');

  let preferredLang = 'en';
  if (cookieHeader) {
    const i18nMatch = cookieHeader.match(/i18n=([a-z]{2})/);
    if (i18nMatch) {
      preferredLang = i18nMatch[1];
    }
  }

  if (preferredLang === 'en' && acceptLanguage) {
    if (acceptLanguage.includes('it') && !acceptLanguage.includes('en')) {
      preferredLang = 'it';
    }
  }

  throw redirect(`/${preferredLang}/admin/dashboard`);
};

export default function AdminDashboard() {
  // This component should never render since the loader always redirects
  return null;
}
