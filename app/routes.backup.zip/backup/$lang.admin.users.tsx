import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { requireAdminUser } from '~/services/admin-auth.server';
import { AdminLayout } from '~/layouts/admin';

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  if (!language) {
    throw redirect('/');
  }

  // Require admin authentication
  await requireAdminUser(request, `/${language}/admin/login`);

  return { language };
};

export default function AdminUsers() {
  return (
    <AdminLayout title="Users" subtitle="Manage authors, editors, and user roles">
      <div
        style={{
          background: 'white',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          padding: '3rem',
          textAlign: 'center',
        }}
      >
        <div
          style={{
            fontSize: '4rem',
            marginBottom: '1rem',
            opacity: 0.3,
          }}
        >
          👥
        </div>

        <h2
          style={{
            margin: '0 0 1rem 0',
            fontSize: '1.5rem',
            fontWeight: 'bold',
            color: '#6c757d',
          }}
        >
          User Management
        </h2>

        <p
          style={{
            margin: '0 0 2rem 0',
            color: '#6c757d',
            fontSize: '1.125rem',
          }}
        >
          User management functionality will be implemented in the next phase.
        </p>

        <div
          style={{
            backgroundColor: '#f8f9fa',
            padding: '1.5rem',
            borderRadius: '8px',
            border: '1px solid #e9ecef',
            textAlign: 'left',
            maxWidth: '600px',
            margin: '0 auto',
          }}
        >
          <h3
            style={{
              margin: '0 0 1rem 0',
              fontSize: '1.125rem',
              fontWeight: 'bold',
            }}
          >
            Planned Features:
          </h3>
          <ul
            style={{
              margin: 0,
              paddingLeft: '1.5rem',
              color: '#6c757d',
              lineHeight: '1.6',
            }}
          >
            <li>Create and manage user accounts</li>
            <li>Role-based access control (Admin, Editor, Author)</li>
            <li>User profile management</li>
            <li>Password reset and email verification</li>
            <li>User activity tracking</li>
            <li>Permission management per user</li>
          </ul>
        </div>
      </div>
    </AdminLayout>
  );
}
