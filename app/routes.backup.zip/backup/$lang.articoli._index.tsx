import type { LoaderFunctionArgs } from '@remix-run/cloudflare';
import { redirect } from '@remix-run/cloudflare';
import { returnLanguageIfSupported } from '~/i18n/i18n.resources';
import { getBlogPostsWithCache } from '~/services/blog.server';
import { Articles } from './articles_._index/articles';

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const language = returnLanguageIfSupported(params.lang);

  // If language is not supported, redirect to root and let it auto-detect
  if (!language) {
    throw redirect('/');
  }

  // Only allow Italian language for "articoli" route
  if (language !== 'it') {
    throw redirect(`/${language}/articles`);
  }

  // Load posts from database with caching (will automatically use Accelerate if available)
  const allPosts = await getBlogPostsWithCache(language);
  const featured = allPosts.find(post => post.featured);
  const posts = allPosts.filter(post => post.slug !== featured?.slug);

  // Combine with language data
  return { posts, featured, lang: language };
};

export default Articles;

export const meta = () => {
  return [
    { title: 'Articoli' },
    {
      name: 'description',
      content: 'Una raccolta di articoli tecnici su design e sviluppo.',
    },
  ];
};

export const handle = {
  i18n: ['articles', 'common'],
};
